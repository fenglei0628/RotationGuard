package dev.rguard.rotation

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val tv = TextView(this).apply {
            text = "RotationGuard 旋转确认

" +
                    "工作原理：接管系统自动旋转。检测到横屏/倒置意图时，在屏幕角落弹出旋转按钮，点击才真正旋转，3 秒不点自动消失。

" +
                    "注意：卸载模块前请点下方停止按钮，或刷入模块目录中的卸载脚本，以恢复系统自动旋转。"
            textSize = 14f
        }

        val btnStart = Button(this).apply { text = "启动 / 重启服务" }
        val btnStop = Button(this).apply { text = "停止服务并恢复系统自动旋转" }

        root.addView(tv)
        root.addView(btnStart)
        root.addView(btnStop)
        setContentView(root)

        btnStart.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
                Toast.makeText(this, "请允许悬浮窗权限后再次点击", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            try {
                Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            } catch (_: Exception) {
                Toast.makeText(this, "写入设置失败，请确认模块 service.sh 已授权", Toast.LENGTH_LONG).show()
            }
            startForegroundService(Intent(this, GuardService::class.java))
            Toast.makeText(this, "已启动", Toast.LENGTH_SHORT).show()
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, GuardService::class.java))
            try {
                Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1)
                Toast.makeText(this, "已停止并恢复系统自动旋转", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "恢复失败，请手动在系统设置里打开自动旋转", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()
}
