package dev.rguard.rotation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.OrientationEventListener
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.Toast

class GuardService : Service() {

    companion object {
        private const val NOTI_ID = 1
        private const val CHANNEL = "guard"
        private const val TIMEOUT_MS = 3000L        // 悬浮按钮停留时间（毫秒）
        private const val HYSTERESIS_DEG = 35       // 触发回差（度）
        private const val FLAT_Z = 7.5f             // |加速度z|超过此值视为躺平，不触发
    }

    private lateinit var sm: SensorManager
    private var orientationListener: OrientationEventListener? = null
    private var accelListener: SensorEventListener? = null
    private var accelZ = 10f

    private var overlay: View? = null
    private var overlayTarget = -1
    private var dismissTask: Runnable? = null
    private val handler = Handler(Looper.getMainLooper())

    private var lastAngle = -1        // 上次已处理的角度
    private var latestAngle = -1      // 最近一次传感器角度
    private var applying = false

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTI_ID, buildNotification())

        sm = getSystemService(SENSOR_SERVICE) as SensorManager

        accelListener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) { accelZ = e.values[2] }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(accelListener, it, SensorManager.SENSOR_DELAY_UI)
        }

        orientationListener = object : OrientationEventListener(this, SensorManager.SENSOR_DELAY_UI) {
            override fun onOrientationChanged(angle: Int) {
                if (angle == ORIENTATION_UNKNOWN) return
                latestAngle = angle
                if (!applying) onAngle(angle)
            }
        }
        orientationListener?.enable()
    }

    /** 角度 -> 目标旋转方向 */
    private fun targetOf(angle: Int): Int = when {
        angle < 45 || angle > 314 -> Surface.ROTATION_0
        angle < 135 -> Surface.ROTATION_270   // 手机顶部朝左
        angle < 225 -> Surface.ROTATION_180
        else -> Surface.ROTATION_90           // 手机顶部朝右
    }

    private fun onAngle(angle: Int) {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) { dismissOverlay(); return }
        if (Math.abs(accelZ) > FLAT_Z) return          // 躺平朝上/朝下，不判断

        val cur = currentRotation()
        val target = targetOf(angle)

        // 已经转回当前显示方向：撤掉残留按钮
        if (target == cur) {
            lastAngle = angle
            dismissOverlay()
            return
        }
        if (lastAngle < 0) { lastAngle = angle; return }
        if (angleDiff(angle, lastAngle) < HYSTERESIS_DEG) return
        if (overlayTarget == target) return

        showButton(target)
    }

    private fun currentRotation(): Int =
        if (Build.VERSION.SDK_INT >= 30) {
            display?.rotation ?: Surface.ROTATION_0
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        }

    private fun angleDiff(a: Int, b: Int): Int {
        val d = Math.abs(a - b) % 360
        return if (d > 180) 360 - d else d
    }

    private fun showButton(target: Int) {
        dismissOverlay()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = dp(52)

        val btn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_stat_rotate)
            setColorFilter(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xB3000000.toInt())
                setStroke(dp(1), 0x66FFFFFF)
            }
            setOnClickListener {
                applying = true
                applyRotation(target)
                lastAngle = latestAngle
                dismissOverlay()
                applying = false
            }
        }

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            // 左倒 -> 左下角按钮；右倒/倒置 -> 右下角按钮
            gravity = Gravity.BOTTOM or
                if (target == Surface.ROTATION_270) Gravity.START else Gravity.END
            x = dp(20)
            y = dp(24)
        }

        wm.addView(btn, lp)
        overlay = btn
        overlayTarget = target

        dismissTask = Runnable { dismissOverlay() }
        handler.postDelayed(dismissTask!!, TIMEOUT_MS)
    }

    private fun dismissOverlay() {
        dismissTask?.let { handler.removeCallbacks(it) }
        dismissTask = null
        overlay?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        overlay = null
        overlayTarget = -1
    }

    private fun applyRotation(target: Int) {
        try {
            Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
            Settings.System.putInt(contentResolver, Settings.System.USER_ROTATION, target)
        } catch (e: SecurityException) {
            Toast.makeText(this,
                "缺少WRITE_SETTINGS权限：adb 执行 appops set $packageName WRITE_SETTINGS allow",
                Toast.LENGTH_LONG).show()
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "旋转守护", NotificationManager.IMPORTANCE_MIN))
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_rotate)
            .setContentTitle("RotationGuard 运行中")
            .setContentText("检测到旋转意图时将在角落显示确认按钮（3 秒）")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        orientationListener?.disable()
        accelListener?.let { sm.unregisterListener(it) }
        dismissOverlay()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
