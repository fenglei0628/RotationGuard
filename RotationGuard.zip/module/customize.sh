#!/system/bin/sh
ui_print "- RotationGuard 旋转确认 v1.0.0"
ui_print "- 以系统应用方式安装，开机自启并接管自动旋转"
set_perm_recursive $MODPATH 0 0 0755 0644
