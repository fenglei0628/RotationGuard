#!/system/bin/sh
# 恢复系统自动旋转
settings put system accelerometer_rotation 1
