#!/system/bin/sh
MODDIR=${0%/*}
PKG=dev.rguard.rotation

until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 2; done
sleep 15

# 确保应用启用，并授予悬浮窗与写入设置权限
pm enable $PKG 2>/dev/null
appops set $PKG SYSTEM_ALERT_WINDOW allow 2>/dev/null
appops set $PKG WRITE_SETTINGS allow 2>/dev/null

# 接管自动旋转：关闭系统自动转，改由 App 检测 + 确认
settings put system accelerometer_rotation 0
