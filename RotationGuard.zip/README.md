# RotationGuard

侧躺看手机不再被自动旋转打扰：检测到旋转意图时，在屏幕左下/右下角弹一个旋转按钮，3 秒不点自动消失，点了才真正旋转。

## 构建（无需本地装任何环境，GitHub 免费编译）

1. 在 GitHub 新建一个仓库（如 RotationGuard），把本目录全部文件上传（可直接网页拖入）
2. 等约 3-5 分钟，Actions 会自动跑完
3. 进入 Actions → 最新一次运行 → Artifacts → 下载 **RotationGuard-ksu**
4. 得到 `RotationGuard-ksu.zip`，在 KernelSU 管理器中刷入，重启即可

## 本地构建（可选）
用 Android Studio 打开工程，Build APK 后，把 `app-debug.apk` 重命名为 `RotationGuard.apk`，
放进 `module/system/app/RotationGuard/`，再把 `module/` 整个压缩成 zip 刷入。

## 卸载
`ksud module uninstall rotation_guard`，或在 KSU 管理器卸载，系统自动旋转恢复。
